import streamlit as st
import plotly.express as px
import pandas as pd

from utils import load_data, clean_data, calculate_kpis

# ----------------------------
# Page Configuration
# ----------------------------
st.set_page_config(
    page_title="Dashboard",
    page_icon="📊",
    layout="wide"
)

# ----------------------------
# Dashboard Title
# ----------------------------
st.title("📊 Sales Dashboard")
st.markdown("Analyze historical sales performance and business trends.")

# ----------------------------
# Load Data
# ----------------------------
df = load_data()
df = clean_data(df)

# ----------------------------
# Sidebar Filters
# ----------------------------
st.sidebar.header("🔍 Filter Data")

# Year Filter
years = sorted(df["Year"].unique())
selected_year = st.sidebar.multiselect(
    "Select Year",
    years,
    default=years
)

# Region Filter
regions = sorted(df["Region"].unique())
selected_region = st.sidebar.multiselect(
    "Select Region",
    regions,
    default=regions
)

# Category Filter
categories = sorted(df["Category"].unique())
selected_category = st.sidebar.multiselect(
    "Select Category",
    categories,
    default=categories
)

# Segment Filter
segments = sorted(df["Segment"].unique())
selected_segment = st.sidebar.multiselect(
    "Select Segment",
    segments,
    default=segments
)

# ----------------------------
# Apply Filters
# ----------------------------
filtered_df = df[
    (df["Year"].isin(selected_year)) &
    (df["Region"].isin(selected_region)) &
    (df["Category"].isin(selected_category)) &
    (df["Segment"].isin(selected_segment))
]

# ----------------------------
# Check Empty Data
# ----------------------------
if filtered_df.empty:
    st.warning("⚠️ No data available for the selected filters.")
    st.stop()

# ----------------------------
# Calculate KPIs
# ----------------------------
total_sales, total_profit, total_orders, total_quantity = calculate_kpis(filtered_df)