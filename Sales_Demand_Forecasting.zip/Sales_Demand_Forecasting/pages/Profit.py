import streamlit as st
import pandas as pd
import plotly.express as px

from utils import load_data, clean_data


# ==========================
# PAGE CONFIG
# ==========================

st.set_page_config(
    page_title="Profit Analysis",
    page_icon="💰",
    layout="wide"
)


# ==========================
# TITLE
# ==========================

st.title("💰 Profit Analysis Dashboard")

st.markdown(
"""
Analyze profit performance, profitability trends,
and identify areas for improving business margins.
"""
)


# ==========================
# LOAD DATA
# ==========================

df = load_data()

df = clean_data(df)


# ==========================
# SIDEBAR FILTERS
# ==========================

st.sidebar.header("🔍 Profit Filters")


years = sorted(df["Year"].unique())

selected_year = st.sidebar.multiselect(
    "Select Year",
    years,
    default=years
)


regions = sorted(df["Region"].unique())

selected_region = st.sidebar.multiselect(
    "Select Region",
    regions,
    default=regions
)


categories = sorted(df["Category"].unique())

selected_category = st.sidebar.multiselect(
    "Select Category",
    categories,
    default=categories
)


# ==========================
# FILTER DATA
# ==========================

profit_df = df[
    (df["Year"].isin(selected_year)) &
    (df["Region"].isin(selected_region)) &
    (df["Category"].isin(selected_category))
]


if profit_df.empty:

    st.warning("No data available for selected filters.")

    st.stop()


# ==========================
# PROFIT CALCULATIONS
# ==========================

total_profit = profit_df["Profit"].sum()

total_sales = profit_df["Sales"].sum()

profit_margin = (
    (total_profit / total_sales) * 100
    if total_sales > 0
    else 0
)


total_orders = profit_df["Order ID"].nunique()

