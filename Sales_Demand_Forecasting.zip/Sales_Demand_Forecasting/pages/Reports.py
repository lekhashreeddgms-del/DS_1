import streamlit as st
import pandas as pd
import plotly.express as px

from utils import load_data, clean_data


# ==========================
# PAGE CONFIG
# ==========================

st.set_page_config(
    page_title="Reports",
    page_icon="📋",
    layout="wide"
)


# ==========================
# TITLE
# ==========================

st.title("📋 Business Reports")

st.write(
"""
Generate detailed business reports from sales data.
These reports help in decision making and inventory planning.
"""
)


# ==========================
# LOAD DATA
# ==========================

df = load_data()
df = clean_data(df)


# ==========================
# FILTERS
# ==========================

st.sidebar.header("Report Filters")


year = st.sidebar.multiselect(
    "Select Year",
    sorted(df["Year"].unique()),
    default=sorted(df["Year"].unique())
)


category = st.sidebar.multiselect(
    "Select Category",
    df["Category"].unique(),
    default=df["Category"].unique()
)


region = st.sidebar.multiselect(
    "Select Region",
    df["Region"].unique(),
    default=df["Region"].unique()
)



filtered_df = df[
    (df["Year"].isin(year)) &
    (df["Category"].isin(category)) &
    (df["Region"].isin(region))
]


# ==========================
# SUMMARY REPORT
# ==========================

st.subheader("📊 Overall Business Summary")


col1, col2, col3, col4 = st.columns(4)


with col1:
    st.metric(
        "Total Sales",
        f"${filtered_df['Sales'].sum():,.2f}"
    )


with col2:
    st.metric(
        "Total Profit",
        f"${filtered_df['Profit'].sum():,.2f}"
    )


with col3:
    st.metric(
        "Orders",
        f"{filtered_df['Order ID'].nunique():,}"
    )


with col4:
    st.metric(
        "Quantity Sold",
        f"{filtered_df['Quantity'].sum():,}"
    )


# ==========================
# CATEGORY REPORT
# ==========================

st.markdown("---")

st.subheader("📦 Category Performance")


category_report = (
    filtered_df
    .groupby("Category")
    .agg(
        Sales=("Sales","sum"),
        Profit=("Profit","sum"),
        Quantity=("Quantity","sum")
    )
    .reset_index()
)


st.dataframe(
    category_report,
    use_container_width=True
)


fig = px.bar(
    category_report,
    x="Category",
    y="Sales",
    color="Profit",
    title="Category Sales Performance"
)


st.plotly_chart(
    fig,
    use_container_width=True
)



# ==========================
# REGION REPORT
# ==========================

st.subheader("🌍 Region Performance")


region_report = (
    filtered_df
    .groupby("Region")
    .agg(
        Sales=("Sales","sum"),
        Profit=("Profit","sum"),
        Orders=("Order ID","nunique")
    )
    .reset_index()
)


st.dataframe(
    region_report,
    use_container_width=True
)



fig = px.pie(
    region_report,
    names="Region",
    values="Sales",
    title="Sales Contribution by Region"
)


st.plotly_chart(
    fig,
    use_container_width=True
)



# ==========================
# TOP PRODUCTS
# ==========================

st.subheader("🏆 Top 10 Products")


top_products = (
    filtered_df
    .groupby("Product Name")
    ["Sales"]
    .sum()
    .sort_values(
        ascending=False
    )
    .head(10)
    .reset_index()
)


st.dataframe(
    top_products,
    use_container_width=True
)


fig = px.bar(
    top_products,
    x="Sales",
    y="Product Name",
    orientation="h",
    title="Highest Selling Products"
)


st.plotly_chart(
    fig,
    use_container_width=True
)



# ==========================
# DOWNLOAD REPORTS
# ==========================

st.markdown("---")

st.subheader("📥 Download Reports")


csv = filtered_df.to_csv(index=False)


st.download_button(
    label="Download Complete Report CSV",
    data=csv,
    file_name="Sales_Report.csv",
    mime="text/csv"
)



category_csv = category_report.to_csv(index=False)


st.download_button(
    label="Download Category Report",
    data=category_csv,
    file_name="Category_Report.csv",
    mime="text/csv"
)



region_csv = region_report.to_csv(index=False)


st.download_button(
    label="Download Region Report",
    data=region_csv,
    file_name="Region_Report.csv",
    mime="text/csv"
)



# ==========================
# BUSINESS INSIGHTS
# ==========================

st.markdown("---")

st.subheader("💡 Business Insights")


best_category = (
    category_report
    .sort_values(
        "Sales",
        ascending=False
    )
    .iloc[0]["Category"]
)


best_region = (
    region_report
    .sort_values(
        "Sales",
        ascending=False
    )
    .iloc[0]["Region"]
)


st.success(
f"""
✅ Highest selling category: {best_category}

✅ Best performing region: {best_region}

✅ Reports can be used for inventory planning and demand forecasting.

✅ Sales trends help optimize future stock decisions.
"""
)