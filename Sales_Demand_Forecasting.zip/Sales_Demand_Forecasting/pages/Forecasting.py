import streamlit as st
import pandas as pd
import plotly.express as px

from prophet import Prophet

from utils import load_data, clean_data


# Page Configuration

st.set_page_config(
    page_title="Demand Forecasting",
    page_icon="🤖",
    layout="wide"
)


# Title

st.title("🤖 Demand Forecasting")
st.markdown(
    "Predict future product demand using historical sales data."
)


# Load Data

df = load_data()
df = clean_data(df)


# Aggregate Daily Sales

sales_data = (
    df.groupby("Order Date")["Sales"]
    .sum()
    .reset_index()
)


sales_data.columns = [
    "ds",
    "y"
]


st.subheader("📈 Historical Sales Trend")


fig = px.line(
    sales_data,
    x="ds",
    y="y",
    title="Historical Sales"
)


st.plotly_chart(
    fig,
    use_container_width=True
)

# ==========================================
# FORECAST MODEL
# ==========================================


st.markdown("---")

st.subheader("🔮 Generate Demand Forecast")


forecast_days = st.slider(
    "Select Forecast Period (Days)",
    min_value=30,
    max_value=365,
    value=90
)


if st.button("Generate Forecast"):


    with st.spinner("Training Forecast Model..."):


        model = Prophet()

        model.fit(
            sales_data
        )


        future = model.make_future_dataframe(
            periods=forecast_days
        )


        forecast = model.predict(
            future
        )


    st.success(
        "Forecast Generated Successfully!"
    )


    forecast_result = forecast[
        [
            "ds",
            "yhat",
            "yhat_lower",
            "yhat_upper"
        ]
    ]


    st.subheader(
        "📊 Future Demand Prediction"
    )


    fig = px.line(
        forecast_result,
        x="ds",
        y=[
            "yhat",
            "yhat_lower",
            "yhat_upper"
        ],
        title="Sales Demand Forecast"
    )


    st.plotly_chart(
        fig,
        use_container_width=True
    )

    # ==========================================
# FORECAST TABLE
# ==========================================


    st.subheader(
        "📋 Forecast Data"
    )


    st.dataframe(
        forecast_result.tail(forecast_days),
        use_container_width=True
    )


    # Future Demand Calculation

    future_sales = (
        forecast_result
        .tail(forecast_days)["yhat"]
        .sum()
    )


    st.markdown("---")

    st.subheader(
        "💡 Forecast Insights"
    )


    st.info(
        f"""
        Expected sales for next {forecast_days} days:

        ${future_sales:,.2f}


        Use this prediction to:

        • Maintain optimum inventory levels

        • Reduce stock shortages

        • Avoid overstocking

        • Improve purchasing decisions
        """
    )


    # Download Forecast


    csv = forecast_result.to_csv(
        index=False
    )


    st.download_button(
        "⬇ Download Forecast Report",
        csv,
        "Demand_Forecast.csv",
        "text/csv"
    )