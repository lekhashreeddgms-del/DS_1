import pandas as pd
import streamlit as st

# ===========================
# LOAD DATA
# ===========================

@st.cache_data
def load_data():

    df = pd.read_excel("data/Superstore.xlsx")

    return df


# ===========================
# CLEAN DATA
# ===========================

def clean_data(df):

    df = df.copy()

    # Convert dates
    df["Order Date"] = pd.to_datetime(df["Order Date"])
    df["Ship Date"] = pd.to_datetime(df["Ship Date"])

    # Create new columns
    df["Year"] = df["Order Date"].dt.year
    df["Month"] = df["Order Date"].dt.month_name()
    df["Quarter"] = df["Order Date"].dt.quarter

    return df


# ===========================
# KPI VALUES
# ===========================

def calculate_kpis(df):

    total_sales = df["Sales"].sum()

    total_profit = df["Profit"].sum()

    total_orders = df["Order ID"].nunique()

    total_quantity = df["Quantity"].sum()

    return (
        total_sales,
        total_profit,
        total_orders,
        total_quantity
    )